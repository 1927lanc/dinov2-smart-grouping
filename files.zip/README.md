# DINOv2 Smart Grouping - React Frontend

A modern, beautiful React frontend for the DINOv2 visual clustering application.

## 🎨 Features

- **Modern Dark Theme** with animated gradients
- **Drag & Drop Upload** support (ready to implement)
- **Real-time Stats Display** - Total images, clusters, and status
- **Dynamic Cluster Visualization** - Grouped images in elegant cards
- **Image Modal** - Click to view images in full size
- **Smooth Animations** - Slide-in effects and hover states
- **Fully Responsive** - Works on desktop, tablet, and mobile

## 📦 Installation

### 1. Copy the Files to Your React Project

Copy these files to your `src` folder:
```
src/
├── Results.jsx
├── Results.css
├── App.js (replace existing)
└── App.css (replace existing)
```

### 2. Install Dependencies (if needed)

Make sure you have React installed:
```bash
npm install react react-dom
```

### 3. Update Your Backend CORS

Make sure your FastAPI backend (`main.py`) has CORS enabled for your frontend:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # or your frontend port
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## 🚀 Usage

### 1. Start Your Backend
```bash
cd backend
python main.py
```
Backend should be running on `http://localhost:8000`

### 2. Start Your Frontend
```bash
cd frontend
npm start
```
Frontend should open at `http://localhost:3000`

### 3. Using the Application

1. **Upload Images**: Click "📁 Upload Images" button to select multiple images
2. **Cluster**: Once you have at least 2 images, click "✨ Cluster Images"
3. **View Results**: See your images grouped by similarity
4. **Click Images**: Click any image to view it in full size
5. **Clear All**: Use "🗑️ Clear All" to reset everything

## 🎯 API Endpoints Used

- `GET /images` - Fetch all images with cluster info
- `POST /upload` - Upload new images
- `GET /cluster` - Perform DBSCAN clustering
- `DELETE /clear` - Clear all data

## 🔧 Customization

### Change Colors
Edit the CSS variables in `Results.css`:
```css
:root {
  --accent-primary: #00d4ff;  /* Main accent color */
  --accent-secondary: #7c3aed; /* Secondary accent */
  --bg-primary: #0a0a0b;       /* Background */
}
```

### Change Grid Layout
Modify the grid in `Results.css`:
```css
.cluster-grid {
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1.5rem;
}
```

### API URL
If your backend is on a different port, update in `Results.jsx`:
```javascript
const API_URL = 'http://localhost:8000'; // Change this
```

## 📱 Responsive Breakpoints

- **Desktop**: 1400px+ (full layout)
- **Tablet**: 768px - 1400px (adjusted grid)
- **Mobile**: < 768px (stacked layout, 2-column grid)

## 🐛 Troubleshooting

### CORS Error
Make sure your backend CORS settings include your frontend URL:
```python
allow_origins=["http://localhost:3000"]
```

### Images Not Loading
1. Check that backend is running on port 8000
2. Verify the `uploads` folder exists in your backend
3. Check browser console for errors

### Clustering Not Working
1. Make sure you have at least 2 images uploaded
2. Check backend logs for errors
3. Verify DBSCAN parameters in `clustering.py`

## 🎨 Design Philosophy

This frontend follows modern design principles:
- **Neumorphism-inspired cards** with subtle shadows
- **Gradient accents** for visual interest
- **Smooth animations** for better UX
- **Dark theme** to reduce eye strain
- **High contrast** for better readability

## 📝 License

MIT License - Feel free to use and modify!

## 🤝 Contributing

Feel free to submit issues and enhancement requests!

---

Made with ❤️ for visual clustering enthusiasts
