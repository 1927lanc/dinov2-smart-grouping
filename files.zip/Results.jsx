import React, { useState, useEffect } from 'react';
import './Results.css';

const Results = () => {
  const [clusters, setClusters] = useState({});
  const [loading, setLoading] = useState(false);
  const [totalImages, setTotalImages] = useState(0);
  const [selectedImage, setSelectedImage] = useState(null);

  const API_URL = 'http://localhost:8000';

  useEffect(() => {
    fetchImages();
  }, []);

  const fetchImages = async () => {
    try {
      const response = await fetch(`${API_URL}/images`);
      const data = await response.json();
      
      setTotalImages(data.total);
      
      // Group images by cluster
      const groupedClusters = {};
      data.images.forEach(img => {
        if (img.cluster_id !== null) {
          if (!groupedClusters[img.cluster_id]) {
            groupedClusters[img.cluster_id] = [];
          }
          groupedClusters[img.cluster_id].push(img);
        }
      });
      
      setClusters(groupedClusters);
    } catch (error) {
      console.error('Error fetching images:', error);
    }
  };

  const performClustering = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/cluster`);
      const data = await response.json();
      
      if (response.ok) {
        console.log('Clustering completed:', data);
        await fetchImages();
      } else {
        alert(data.detail || 'Clustering failed');
      }
    } catch (error) {
      console.error('Clustering error:', error);
      alert('Error performing clustering');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (event) => {
    const files = event.target.files;
    if (!files.length) return;

    setLoading(true);
    
    for (let file of files) {
      const formData = new FormData();
      formData.append('file', file);

      try {
        await fetch(`${API_URL}/upload`, {
          method: 'POST',
          body: formData
        });
      } catch (error) {
        console.error('Upload error:', error);
      }
    }

    await fetchImages();
    setLoading(false);
  };

  const clearAll = async () => {
    if (!window.confirm('Are you sure you want to delete all images and clusters?')) {
      return;
    }

    try {
      await fetch(`${API_URL}/clear`, { method: 'DELETE' });
      setClusters({});
      setTotalImages(0);
    } catch (error) {
      console.error('Clear error:', error);
    }
  };

  const clusterCount = Object.keys(clusters).length;

  return (
    <div className="results-container">
      {/* Header */}
      <header className="results-header">
        <div className="header-content">
          <div className="logo">
            <div className="logo-icon">D</div>
            <div className="logo-text">
              <h1>DINOv2 Smart Grouping</h1>
              <span className="subtitle">Visual Clustering Dashboard</span>
            </div>
          </div>
          
          <div className="header-actions">
            <label className="btn btn-secondary">
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleFileUpload}
                style={{ display: 'none' }}
              />
              📁 Upload Images
            </label>
            
            <button 
              className="btn btn-primary" 
              onClick={performClustering}
              disabled={loading || totalImages < 2}
            >
              ✨ Cluster Images
            </button>
            
            <button className="btn btn-danger" onClick={clearAll}>
              🗑️ Clear All
            </button>
          </div>
        </div>
      </header>

      {/* Stats Bar */}
      <div className="stats-bar">
        <div className="stat-card">
          <div className="stat-label">Total Images</div>
          <div className="stat-value">{totalImages}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Clusters Found</div>
          <div className="stat-value">{clusterCount}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Status</div>
          <div className="stat-value status-text">
            {loading ? 'Processing...' : clusterCount > 0 ? 'Clustered' : 'Ready'}
          </div>
        </div>
      </div>

      {/* Loading Spinner */}
      {loading && (
        <div className="loading-overlay">
          <div className="spinner"></div>
          <p>Processing images...</p>
        </div>
      )}

      {/* Clusters Display */}
      <div className="clusters-section">
        {clusterCount === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🖼️</div>
            <h2>No clusters yet</h2>
            <p>Upload images and click "Cluster Images" to get started</p>
          </div>
        ) : (
          Object.keys(clusters)
            .sort((a, b) => a - b)
            .map((clusterId, index) => (
              <div 
                key={clusterId} 
                className="cluster-group"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="cluster-header">
                  <h2>Group {parseInt(clusterId) + 1}</h2>
                  <span className="cluster-badge">
                    {clusters[clusterId].length} Images
                  </span>
                </div>
                
                <div className="cluster-grid">
                  {clusters[clusterId].map((image) => (
                    <div 
                      key={image.id} 
                      className="image-card"
                      onClick={() => setSelectedImage(`${API_URL}${image.url}`)}
                    >
                      <div className="image-wrapper">
                        <img 
                          src={`${API_URL}${image.url}`} 
                          alt={image.filename}
                          loading="lazy"
                        />
                      </div>
                      <div className="image-info">
                        <span className="image-filename">{image.filename}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
        )}
      </div>

      {/* Image Modal */}
      {selectedImage && (
        <div className="modal" onClick={() => setSelectedImage(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setSelectedImage(null)}>
              ✕
            </button>
            <img src={selectedImage} alt="Full size" />
          </div>
        </div>
      )}
    </div>
  );
};

export default Results;
