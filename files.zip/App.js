import React from 'react';
import Results from './Results';
import './App.css';

function App() {
  return (
    <div className="App">
      <Results />
    </div>
  );
}

export default App;
